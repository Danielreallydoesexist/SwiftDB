import Foundation

enum DBValue: Codable, Sendable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case array([DBValue])
    case object([String: DBValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()

        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode([DBValue].self) {
            self = .array(value)
        } else if let value = try? container.decode([String: DBValue].self) {
            self = .object(value)
        } else {
            throw DecodingError.dataCorruptedError(
                in: container,
                debugDescription: "Unsupported database value."
            )
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()

        switch self {
        case .string(let value):
            try container.encode(value)

        case .number(let value):
            try container.encode(value)

        case .bool(let value):
            try container.encode(value)

        case .array(let value):
            try container.encode(value)

        case .object(let value):
            try container.encode(value)

        case .null:
            try container.encodeNil()
        }
    }
}